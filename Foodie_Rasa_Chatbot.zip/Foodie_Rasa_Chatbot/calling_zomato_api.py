#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa.core.actions.action import Action
from rasa.core.events import SlotSet
import zomatopy
import json
import pandas as pd

config={"user_key":"7fda9992ede978bc8d1ac1b0b143efb1"}
zomato = zomatopy.initialize_app(config)

def search_restaurants(loc,cuisine,price):
	location_detail=zomato.get_location(loc, 1)
	location_json = json.loads(location_detail)
	location_results = len(location_json['location_suggestions'])
	lat=location_json["location_suggestions"][0]["latitude"]
	lon=location_json["location_suggestions"][0]["longitude"]
	city_id=location_json["location_suggestions"][0]["city_id"]
	cuisines_dict={'american': 1,'chinese': 25, 'north indian': 50, 'italian': 55, 'mexican': 73, 'south indian': 85, 'thai': 95}
		 
		
	retrive_list = [0,20,40,60,80]
	zd = []
	zomato_df = pd.DataFrame()
	for i in retrive_list:
		zomato_results = zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), limit=i)
		zomato_data = json.loads(zomato_results)
		zd = zomato_data['restaurants']
		rest_df = pd.DataFrame([{'restaurant_name': x['restaurant']['name'], 'restaurant_rating': x['restaurant']['user_rating']['aggregate_rating'],
			'restaurant_address': x['restaurant']['location']['address'],'budget_for2people': x['restaurant']['average_cost_for_two']} for x in zd])
		zomato_df = zomato_df.append(rest_df)

	def budget_sorting(row):
		if row['budget_for2people']<300 :
			return 'lesser than 300'
		elif 300<=row['budget_for2people']<700 :
			return 'between 300 to 700'
		else:
			return 'more than 700'

	zomato_df['budget'] = zomato_df.apply(lambda row: budget_sorting (row),axis=1)
	#sort zomato_df on review & filter by budget
	restaurant_dataframe = zomato_df[(zomato_df.budget == price)]
	restaurant_dataframe = restaurant_dataframe.sort_values(['restaurant_rating'], ascending=0)	

	return restaurant_dataframe


