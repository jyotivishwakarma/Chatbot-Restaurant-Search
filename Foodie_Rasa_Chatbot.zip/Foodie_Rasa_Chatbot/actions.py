   #!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import json

from calling_zomato_api import search_restaurants
from user_input_validate_city import validate_city
from validating_email import send_restaurant_email


class ActionSearchRestaurants(Action):

    def name(self):
        return 'action_restaurant'

    def run(self,dispatcher,tracker,domain):

        loc = tracker.get_slot('city')
        cuisine = tracker.get_slot('cuisine')
        price = tracker.get_slot('budget')
        global results1
        results1 = search_restaurants(loc, cuisine, price)
        results = results1.head(5)

        # Listing Top 5 restaurant results

        if len(results) > 0:
            response = 'Showing you the top 5 restaurants in ' + loc \
                + '\n'
            for (index, row) in results.iterrows():
                response = response + str(row['restaurant_name']) \
                    + ' (rated ' + row['restaurant_rating'] + ') in ' \
                    + row['restaurant_address'] \
                    + ' and the average budget for two people ' \
                    + str(row['budget_for2people']) + '\n'


            dispatcher.utter_message(str(response))
            return [SlotSet('restaurant_found', 'found')]
        else:
            response = 'No restaurants found'
            dispatcher.utter_message(str(response))
            return [SlotSet('restaurant_found', 'notfound')]


class ActionChecklocation(Action):

    def name(self):
        return 'action_check_location'

    def run(
        self,
        dispatcher,
        tracker,
        domain,
        ):

        loc = tracker.get_slot('city')
        if type(loc) == type(None):
            loc = 'JUNK'

        check = validate_city(loc.lower())

        return [SlotSet('city', check['location_validated']),
                SlotSet('location_found', check['location_user'])]

class ActionSendRestaurantListByMail(Action):

    def name(self):
        return 'action_email_restaurant_details'

    def run(
        self,
        dispatcher,
        tracker,
        domain,
        ):

        recipient = tracker.get_slot('email')
        restaurants = results1.head(10)

        print("Correct email format is {}".format(recipient))
        send_restaurant_email(recipient, restaurants)

        dispatcher.utter_message('Please check your mail inbox, Kindly check Junk folder if not found in Inbox!'
                                 )
