1. Requirement.txt has all the updated versions used for this project

2. In validating_email.py file 
update following fields: 
         "MAIL_USERNAME": "your_id@gmail.com"
         "MAIL_PASSWORD": "your_passwd"


3. slack recording available in folder : foodie_chatbot

4. Mail sent from foodie is attached for : example foodie_mail


