## intent:greet
- hey hi
- hi
- hello
- Hi
- Hola
- hey
- Helloz
- howdy
- houdy
- Hey
- hola

## intent:findRestaurants_CLB
- looking for restaurants in [poona](city:pune)
- searching for [chinese](cuisine) eat outs around [pune](city)
- [goa](city)
- [italian](cuisine)
- [yashashripardeshi.com](email)
- [Delhi](city)
- looking for restaurants in [dilli](city:Delhi)
- [south indian](cuisine)
- can you suggest some good restaurants in [Indore](city)
- [american](cuisine)
- i'm hungry looking for some restaurants
- [chenai](city:Chennai)
- [madras](city:Chennai)
- looking out for some [mexican](cuisine) restaurants in [dilli](city)
- [mubaim](city:mumbai)
- [bombay](city:mumbai)
- looking for restaurants in [junk](city)
- [junkjunk](city)
- [mumbai](city)
- looking for restaurants in [italy](city)
- [chennai](city)
- [mexican](cuisine)
- find restaurant
- [Pune](city:pune)
- [South Indian](cuisine:south indian)
- lookin for restaurant in [pune](city)
- [Mexican](cuisine:mexican)
- looking for restaurant
- [Ahmednagar](city)
- [chinese](cuisine)
- I am searching for restaurant
- [Ajmer](city:ajmer)
- [north indian](cuisine)
- I am searching for a restaurant
- looking for reataurant in [dilli](city:Delhi)
- [yashashripardeshi@gmail.com](email)
- [abc@gmail.com](email)
- finding restaurants around [dilli](city:Delhi)
- I am looking [mexican](cuisine) restaurants aroud [Indore](city:indore)
- looking for restaurant in [mumbai](city)
- searching for restaurant in [nagar](city)
- [poona](city:pune)
- searching restaurant around [new york](city)
- searching restaurants in [satara](city)
- [pune](city)
- looking for [italian](cuisine) estaurant around [pune](city)
- I am looking for [italian](cuisine) restaurant in [dubai](city)
- can you please look for restaurant in [madras](city:Chennai)?
- I'm hungry, looking for some good restaurant
- [bengaluru](city:Bangalore)
- I'm hungry looking out for some restaurant
- i'll prefer [mexican](cuisine)
- can you suggest some good restaurant in [Rishikesh](city)
- okey, show me some in [Allahbad](city:allahbad)
- can you suggest some restaurant in [kolkata](city)
- am hungry looking for restaurant
- in [mubaim](city:mumbai)
- looking for restaurants in [chandigarh](city)
- [chines](cuisine:Chinese)

## intent:budget
- [more than 700](budget)
- [< 300](budget:lesser than 300)
- [> 700](budget:more than 700)
- [less 300](budget:lesser than 300)
- [bw 300](budget:between 300 to 700)
- [300-700](budget:between 300 to 700)
- [bw 300 & 700](budget:between 300 to 700)
- [btw 300-700](budget:between 300 to 700)
- [300 or less](budget:lesser than 300)
- [mt 700](budget:more than 700)
- [bet 300](budget:between 300 to 700)
- [lt 300](budget:lesser than 300)
- [300-700](budget:between 300 to 700) range
- [<300](budget:lesser than 300)
- [>700](budget:more than 700)
- [<300](budget:lesser than 300)

## intent:affirmative
- [y](interested)
- [ye](interested)
- Thanks
- Yes(interested)
- yes(interested)
- [yes](interested)
- [yea](interested)
- [yep](interested)
- [yes](interested), please send to [yashashripardeshi@gmail.com](email)

## intent:negative
- no
- nope
- dont want

## intent:bye
- thank you
- [thanks!](bye)
- chaos
- see ya
- tata
- b bye
- goodbye
- good bye
- bye, thank you!
- chao! not needed
- tata bye!
- [tata bye bye !](bye)
- [bye bye, thank you !](bye)
- not needed , Thank you
- [no,thanks](bye)
- [no, thanks](bye)

## synonym:Bangalore
- bengaluru
- Blore

## synonym:Chennai
- chenai
- madras

## synonym:Delhi
- dilli

## synonym:ajmer
- Ajmer

## synonym:allahbad
- Allahbad

## synonym:between 300 to 700
- bw 300
- 300-700
- bw 300 & 700
- btw 300-700
- bet 300

## synonym:indore
- Indore

## synonym:lesser than 300
- < 300
- less 300
- 300 or less
- lt 300
- <300

## synonym:mexican
- Mexican

## synonym:more than 700
- > 700
- mt 700
- >700

## synonym:mumbai
- mubaim
- bombay

## synonym:pune
- poona
- Pune

## synonym:south indian
- South Indian

## synonym:yes
- Yes
