## complete path 1
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "Pune"}
    - slot{"city": "Pune"}
    - action_check_location
    - slot{"city": "pune"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* budget{"budget": "lesser than 300"}
    - slot{"budget": "lesser than 300"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative
    - utter_final_bye

## complete path 2
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "delhi"}
    - slot{"city": "delhi"}
    - action_check_location
    - slot{"city": "delhi"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - action_restaurant
    - slot{"restaurant_found": "notfound"}
    - utter_budget_modify
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative
    - utter_final_bye

## complete path 3
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "Ahmednagar"}
    - slot{"city": "Ahmednagar"}
    - action_check_location
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "goa"}
    - slot{"city": "goa"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - action_restaurant
    - slot{"restaurant_found": "notfound"}
    - utter_final_bye

## complete path 4
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "kulti"}
    - slot{"city": "kulti"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "goa"}
    - slot{"city": "goa"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative
    - utter_final_bye

## complete path 5
* greet
    - utter_greet
* findRestaurants_CLB{"city": "delhi"}
    - slot{"city": "delhi"}
    - action_check_location
    - slot{"city": "delhi"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - utter_ask_mail
* affirmative{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_6
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "pune"}
    - slot{"city": "pune"}
    - action_check_location
    - slot{"city": "pune"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_budget
* budget{"budget": "lesser than 300"}
    - slot{"budget": "lesser than 300"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative
    - utter_final_bye

## interactive_story_7
* greet
    - utter_greet
* findRestaurants_CLB{"city": "pune"}
    - slot{"city": "pune"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - action_check_location
    - slot{"city": "pune"}
    - slot{"location_found": "found"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative
    - utter_final_bye

## interactive_story_8
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "Ahmednagar"}
    - slot{"city": "Ahmednagar"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* greet{"city": "ranchi"}
    - slot{"city": "ranchi"}
    - action_check_location
    - slot{"city": "ranchi"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative
    - utter_final_bye

## interactive_story_9
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "ajmer"}
    - slot{"city": "ajmer"}
    - action_check_location
    - slot{"city": "ajmer"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - utter_ask_mail
* affirmative{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_10
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "ajmer"}
    - slot{"city": "ajmer"}
    - action_check_location
    - slot{"city": "ajmer"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* budget{"budget": "bw 300"}
    - slot{"budget": "bw 300"}
    - action_restaurant
    - slot{"restaurant_found": "notfound"}
    - utter_budget_modify
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
* bye{"bye": "thanks!"}
    - utter_final_bye

## interactive_story_11
* greet
    - utter_greet
* findRestaurants_CLB{"city": "junk"}
    - slot{"city": "junk"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "junkjunk"}
    - slot{"city": "junkjunk"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "notfound"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "mumbai"}
    - slot{"city": "mumbai"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* negative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashri.pardeshi@.in.ibm.com"}
    - slot{"email": "yashashri.pardeshi@.in.ibm.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_12
* greet
    - utter_greet
* findRestaurants_CLB{"cuisine": "south indian", "city": "mangalore"}
    - slot{"cuisine": "south indian"}
    - slot{"city": "mangalore"}
    - action_check_location
    - slot{"city": "mangalore"}
    - slot{"location_found": "found"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - utter_ask_mail
* affirmative{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_13
* greet
    - utter_greet
* findRestaurants_CLB{"city": "Delhi"}
    - slot{"city": "Delhi"}
    - action_check_location
    - slot{"city": "delhi"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_14
* greet
    - utter_greet
* findRestaurants_CLB{"city": "Delhi"}
    - slot{"city": "Delhi"}
    - action_check_location
    - slot{"city": "delhi"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_15
* greet
    - utter_greet
* findRestaurants_CLB{"cuisine": "mexican", "city": "indore"}
    - slot{"city": "indore"}
    - slot{"cuisine": "mexican"}
    - action_check_location
    - slot{"city": "indore"}
    - slot{"location_found": "found"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_16
* greet
    - utter_greet
* findRestaurants_CLB{"city": "mumbai"}
    - slot{"city": "mumbai"}
    - action_check_location
    - slot{"city": "mumbai"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_budget
* budget{"budget": "lesser than 300"}
    - slot{"budget": "lesser than 300"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_17
* greet
    - utter_greet
* findRestaurants_CLB{"city": "nagar"}
    - slot{"city": "nagar"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "pune"}
    - slot{"city": "pune"}
    - action_check_location
    - slot{"city": "pune"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_18
* greet
    - utter_greet
* findRestaurants_CLB{"city": "new york"}
    - slot{"city": "new york"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* negative
    - utter_final_bye

## interactive_story_19
* greet
    - utter_greet
* findRestaurants_CLB{"city": "satara"}
    - slot{"city": "satara"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "pune"}
    - slot{"city": "pune"}
    - action_check_location
    - slot{"city": "pune"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_20
* greet
    - utter_greet
* findRestaurants_CLB{"cuisine": "italian", "city": "pune"}
    - slot{"city": "pune"}
    - slot{"cuisine": "italian"}
    - action_check_location
    - slot{"city": "pune"}
    - slot{"location_found": "found"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* bye
    - utter_final_bye

## interactive_story_21
* greet
    - utter_greet
* findRestaurants_CLB{"cuisine": "italian", "city": "dubai"}
    - slot{"city": "dubai"}
    - slot{"cuisine": "italian"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* bye
    - utter_final_bye

## interactive_story_22
* greet
    - utter_greet
* bye{"bye": "tata bye bye !"}
    - utter_final_bye

## interactive_story_23
* greet
    - utter_greet
* findRestaurants_CLB{"city": "Chennai"}
    - slot{"city": "Chennai"}
    - action_check_location
    - slot{"city": "chennai"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* bye{"bye": "tata bye bye !"}
    - utter_final_bye


## interactive_story_24
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "Bangalore"}
    - slot{"city": "Bangalore"}
    - action_check_location
    - slot{"city": "bangalore"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_budget
* budget{"budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes", "email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - slot{"interested": "yes"}
    - action_email_restaurant_details
* bye{"bye": "bye bye, thank you !"}
    - utter_final_bye

## interactive_story_25
* greet
    - utter_greet
* findRestaurants_CLB{"city": "Rishikesh"}
    - slot{"city": "Rishikesh"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* findRestaurants_CLB{"city": "allahbad"}
    - slot{"city": "allahbad"}
    - action_check_location
    - slot{"city": null}
    - slot{"location_found": "tier3"}
    - utter_foodie_not_working
* bye
    - utter_final_bye

## interactive_story_26
* greet
    - utter_greet
* findRestaurants_CLB{"city": "kolkata"}
    - slot{"city": "kolkata"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - action_check_location
    - slot{"city": "kolkata"}
    - slot{"location_found": "found"}
    - utter_ask_budget
* budget{"budget": "lesser than 300"}
    - slot{"budget": "lesser than 300"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* affirmative{"interested": "yes"}
    - slot{"interested": "yes"}
    - utter_ask_mail
* findRestaurants_CLB{"email": "yashashripardeshi@gmail.com"}
    - slot{"email": "yashashripardeshi@gmail.com"}
    - action_email_restaurant_details
    - utter_final_bye

## interactive_story_27
* greet
    - utter_greet
* findRestaurants_CLB
    - utter_ask_location
* findRestaurants_CLB{"city": "mumbai"}
    - slot{"city": "mumbai"}
    - action_check_location
    - slot{"city": "mumbai"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* budget{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* bye{"bye": "no,thanks"}
    - utter_final_bye

## interactive_story_28
* greet
    - utter_greet
* findRestaurants_CLB{"city": "chandigarh"}
    - slot{"city": "chandigarh"}
    - action_check_location
    - slot{"city": "chandigarh"}
    - slot{"location_found": "found"}
    - utter_ask_cuisine
* findRestaurants_CLB{"cuisine": "Chinese"}
    - slot{"cuisine": "Chinese"}
    - utter_ask_budget
* budget{"budget": "lesser than 300"}
    - slot{"budget": "lesser than 300"}
    - action_restaurant
    - slot{"restaurant_found": "found"}
    - utter_ask_ifinterested
* bye{"bye": "no, thanks"}
    - utter_final_bye
